/* ── Toast styles (injected once by JS) ─────────────────────── */
(function injectToastStyles() {
    if (document.getElementById("__toast-styles")) return;
    const style = document.createElement("style");
    style.id = "__toast-styles";
    style.textContent = `
        #toast-container {
            position: fixed;
            bottom: clamp(12px, 3vw, 24px);
            right:  clamp(12px, 3vw, 24px);
            display: flex;
            flex-direction: column-reverse;
            gap: 10px;
            z-index: 9999;
            /* On very small screens stretch to full width */
            max-width: min(340px, calc(100vw - 24px));
            width: 100%;
        }

        .toast {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 13px 16px;
            border-radius: 10px;
            font-family: 'Segoe UI', system-ui, sans-serif;
            font-size: clamp(13px, 2.5vw, 14px);
            line-height: 1.45;
            color: #fff;
            box-shadow: 0 8px 24px rgba(0,0,0,0.22);
            cursor: pointer;
            /* slide-up + fade in */
            animation: toastIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
            will-change: transform, opacity;
            word-break: break-word;
        }

        .toast.removing {
            animation: toastOut 0.25s ease forwards;
        }

        .toast-icon {
            font-size: 16px;
            flex-shrink: 0;
            margin-top: 1px;
        }

        .toast-body { flex: 1; }
        .toast-title {
            font-weight: 600;
            margin-bottom: 2px;
            font-size: clamp(13px, 2.5vw, 14px);
        }
        .toast-message { opacity: 0.9; }

        .toast-progress {
            position: absolute;
            bottom: 0; left: 0;
            height: 3px;
            border-radius: 0 0 10px 10px;
            background: rgba(255,255,255,0.45);
            animation: toastProgress var(--toast-duration, 3s) linear forwards;
        }

        .toast { position: relative; overflow: hidden; }

        /* Colour variants */
        .toast-info    { background: #1d4ed8; }
        .toast-success { background: #15803d; }
        .toast-warning { background: #b45309; color: #fff; }
        .toast-error   { background: #b91c1c; }
        .toast-default { background: #1e293b; }

        @keyframes toastIn {
            from { opacity: 0; transform: translateY(16px) scale(0.95); }
            to   { opacity: 1; transform: translateY(0)    scale(1);    }
        }
        @keyframes toastOut {
            from { opacity: 1; transform: translateY(0)    scale(1);    }
            to   { opacity: 0; transform: translateY(8px)  scale(0.95); }
        }
        @keyframes toastProgress {
            from { width: 100%; }
            to   { width: 0%;   }
        }
    `;
    document.head.appendChild(style);
})();


/* ── Toast API ──────────────────────────────────────────────── */

/**
 * showToast(message, options)
 *
 * @param {string} message   - Main body text
 * @param {object} [options]
 *   @param {string} [options.title]    - Bold heading above the message
 *   @param {'default'|'info'|'success'|'warning'|'error'} [options.type='default']
 *   @param {number} [options.duration=3500]  - ms before auto-dismiss (0 = sticky)
 */
function showToast(message, options = {}) {
    const {
        title    = "",
        type     = "default",
        duration = 3500,
    } = options;

    // Icons mapped to type
    const icons = {
        info:    "ℹ️",
        success: "✅",
        warning: "⚠️",
        error:   "❌",
        default: "💬",
    };

    // Ensure container exists
    let container = document.getElementById("toast-container");
    if (!container) {
        container = document.createElement("div");
        container.id = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.style.setProperty("--toast-duration", `${duration}ms`);
    toast.setAttribute("role", "alert");
    toast.setAttribute("aria-live", "polite");

    toast.innerHTML = `
        <span class="toast-icon">${icons[type] ?? icons.default}</span>
        <div class="toast-body">
            ${title ? `<div class="toast-title">${title}</div>` : ""}
            <div class="toast-message">${message}</div>
        </div>
        ${duration > 0 ? '<div class="toast-progress"></div>' : ""}
    `;

    const dismiss = () => {
        toast.classList.add("removing");
        toast.addEventListener("animationend", () => toast.remove(), { once: true });
    };

    toast.addEventListener("click", dismiss);

    container.appendChild(toast);

    if (duration > 0) setTimeout(dismiss, duration);

    return { dismiss }; // allow programmatic dismiss
}


/* ── Convenience shortcuts ──────────────────────────────────── */
const toast = {
    info:    (msg, opts) => showToast(msg, { type: "info",    ...opts }),
    success: (msg, opts) => showToast(msg, { type: "success", ...opts }),
    warning: (msg, opts) => showToast(msg, { type: "warning", ...opts }),
    error:   (msg, opts) => showToast(msg, { type: "error",   ...opts }),
};

/* Usage examples (uncomment to test):
   showToast("Profile saved!", { type: "success", title: "Done" });
   toast.error("Something went wrong. Please try again.", { duration: 5000 });
   toast.warning("Your session is about to expire.");
   showToast("Processing…", { type: "info", duration: 0 }); // sticky
*/
